import cv2,os
from keras.models import load_model
import numpy as np
from keras.preprocessing import image
import glob


def load_image(img_path, show=False):
	# (height, width, channels)
    img = image.load_img(img_path, target_size=(224, 224, 3))
    # (1, height, width, channels), add a dimension because the model expects this shape: (batch_size, height, width)
    img_tensor = image.img_to_array(img)
    img_tensor = np.expand_dims(img_tensor, axis=0)
    img_tensor /= 255.
    if show:
        pyplot.imshow(img_tensor[0])
        pyplot.axis('off')
        pyplot.show()
    return img_tensor


def accuracy():
    acc_count = 0
    f_defect = glob.glob("D:\\SIH fabric-test\\dataset\\original\\Defect_images\\*.png")
    f_noDefect = glob.glob("D:\\SIH fabric-test\\dataset\\original\\NODefect_images\\*.png")
    model = load_model("C:\\project\\fabric model\\model.h5")
    for img in f_noDefect:
        test_image = load_image(img)
        pred = model.predict(test_image)
        if pred > 0.5:
            acc_count += 1
    for img in f_defect:
        test_image = load_image(img)
        pred = model.predict(test_image)
        if pred < 0.5:
            acc_count += 1
    
    print("Total Testing Accuracy: ", acc_count/(len(f_defect)+ len(f_noDefect)))
    
accuracy()